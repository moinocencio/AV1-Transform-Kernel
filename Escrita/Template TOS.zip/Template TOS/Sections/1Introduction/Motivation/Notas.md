# Notas: Motivação

## Tópicos:
* Desenvolvimento da qualidade de vídeo ao consumidor final
* Payload global do vídeo no uso da internet
* Depêndencia das baterias para aplicações móveis
* Hardware dedicado melhora performance e consumo energético

### MOVR 2018:
https://www.scientiamobile.com/growing-support-of-hevc-or-h-265-video-on-mobile-devices/

Overview das implementações de HEVC em smartphones e previsões sobre payload de vídeos nos próximos anos (https://www.cisco.com/c/en/us/solutions/collateral/service-provider/visual-networking-index-vni/white-paper-c11-741490.html#_Toc484813971)
